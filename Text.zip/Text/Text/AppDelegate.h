//
//  AppDelegate.h
//  Text
//
//  Created by choi hyunill on 2016. 12. 27..
//  Copyright © 2016년 HyunILL CHOI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

